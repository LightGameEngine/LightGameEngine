const rootDiv=document.createElement("div");document.head.appendChild(rootDiv);let themes={},theme;function setTheme(e,t=!0){theme=e;const o=themes[theme];rootDiv.innerHTML=`
<style>
:root {
${Object.keys(o.json).map(e=>`    --${e}: ${o.json[e]};`).join("\n")}
}
</style>`,t&&ws.sendPacketForce("set_theme",{theme:theme})}addWSListener("get_theme",e=>{themes=e.themes,setTheme(e.id,!1)}),setTimeout(()=>theme?null:window.location.href=window.location.href+"",1e3);